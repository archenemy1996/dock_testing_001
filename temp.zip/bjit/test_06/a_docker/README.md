# aws_trial_02
